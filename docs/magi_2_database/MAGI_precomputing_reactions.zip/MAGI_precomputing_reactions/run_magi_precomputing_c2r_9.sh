#!/bin/bash

# Nr of the run (1-25)
nr=9

## Compounds to search are in
compounds=./input_files/substrates_$nr.csv

## Other settings
min_diameter=0
cpu_count=1
output_dir=./output_$nr
magi_repo=/global/cscratch1/sd/leegwate/magi

## Log files
logfile=./log_c2r_$nr.txt
error_logfile=./error_log_c2r_$nr.txt

## Run compound to reaction search
source activate ../../magi/magi_2

python $magi_repo/workflow_2/compound_to_reaction.py \
    --compounds $compounds \
    --diameter $min_diameter \
    --cpu_count $cpu_count \
    --use_precomputed_reactions False \
    --output $output_dir > $logfile 2> $error_logfile
